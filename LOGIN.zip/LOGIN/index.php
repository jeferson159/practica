<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bienvenidos</title>
        <link rel = "preconnect" href = "https://fonts.googleapis.com">
        <link rel = "preconnect" href = "https://fonts.gstatic.com" crossorigin>
        <link href = "https: //fonts.googleapis.com/css2? family = Roboto: wght @ 100 & display = swap "rel =" stylesheet ">
        <link rel="stylesheet" href="assets/css/estilos.css">
    </head>
    <body>

    <h1>Ingrese o registrate</h1>
    <a href="inicio.php">Iniciar sesion</a> or
    <a href="registro.php">registrarse</a>
</body>
</html>